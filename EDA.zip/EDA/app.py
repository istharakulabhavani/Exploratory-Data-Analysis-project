import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px

st.set_page_config(page_title="EDA Dashboard", page_icon="📊", layout="wide")

st.title("📊 Exploratory Data Analysis (EDA) Dashboard")

uploaded_file = st.file_uploader("Upload CSV File", type=["csv"])

if uploaded_file is not None:

    df = pd.read_csv(uploaded_file)

    st.success("Dataset Uploaded Successfully!")

    st.subheader("Dataset Preview")
    st.dataframe(df)

    st.subheader("Dataset Shape")
    col1, col2 = st.columns(2)

    col1.metric("Rows", df.shape[0])
    col2.metric("Columns", df.shape[1])

    st.subheader("Column Information")
    st.write(df.dtypes)

    st.subheader("Missing Values")
    st.dataframe(df.isnull().sum())

    st.subheader("Summary Statistics")
    st.dataframe(df.describe())

    numeric_columns = df.select_dtypes(include='number').columns.tolist()

    st.sidebar.header("Visualization")

    chart = st.sidebar.selectbox(
        "Choose Chart",
        [
            "Histogram",
            "Box Plot",
            "Scatter Plot",
            "Correlation Heatmap",
            "Bar Chart",
            "Pie Chart"
        ]
    )

    if chart == "Histogram":

        column = st.selectbox("Select Numeric Column", numeric_columns)

        fig = px.histogram(df, x=column, color_discrete_sequence=['royalblue'])
        st.plotly_chart(fig, use_container_width=True)

    elif chart == "Box Plot":

        column = st.selectbox("Select Numeric Column", numeric_columns)

        fig = px.box(df, y=column, color_discrete_sequence=['green'])
        st.plotly_chart(fig, use_container_width=True)

    elif chart == "Scatter Plot":

        x = st.selectbox("X-axis", numeric_columns)

        y = st.selectbox("Y-axis", numeric_columns, index=1)

        color = st.selectbox("Color", df.columns)

        fig = px.scatter(df, x=x, y=y, color=color)

        st.plotly_chart(fig, use_container_width=True)

    elif chart == "Correlation Heatmap":

        fig, ax = plt.subplots(figsize=(8,6))

        sns.heatmap(df[numeric_columns].corr(),
                    annot=True,
                    cmap="coolwarm",
                    ax=ax)

        st.pyplot(fig)

    elif chart == "Bar Chart":

        cat = st.selectbox(
            "Select Categorical Column",
            df.select_dtypes(include='object').columns
        )

        fig = px.bar(
            df[cat].value_counts().reset_index(),
            x='index',
            y=cat
        )

        st.plotly_chart(fig, use_container_width=True)

    elif chart == "Pie Chart":

        cat = st.selectbox(
            "Select Categorical Column",
            df.select_dtypes(include='object').columns
        )

        fig = px.pie(
            values=df[cat].value_counts().values,
            names=df[cat].value_counts().index
        )

        st.plotly_chart(fig, use_container_width=True)

else:

    st.info("Please upload a CSV file to start analysis.")